const layoutPath = 'global\\ui\\layouts\\bankexpansionlayouthd.json';
const layout = D2RMM.readJson(layoutPath);

const anchor = {
  type: 'Widget',
  name: 'StashSearchAnchor',
  fields: {
    rect: {
      x: config.anchorX,
      y: config.anchorY,
      width: config.anchorWidth,
      height: config.anchorHeight,
    },
  },
};

layout.children = layout.children.filter(child => child.name !== anchor.name);
layout.children.push(anchor);

D2RMM.writeJson(layoutPath, layout);
