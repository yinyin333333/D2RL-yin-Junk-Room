D2RMM.copyFile("MyMod","",!0);
